// const form = document.querySelector("form");
const inputText = document.querySelector("#typing-text");
const randomText = document.querySelector(".random-text");
const time = document.querySelector("#time");
const score = document.querySelector("#score");
const modal = document.querySelector(".game-modal");
const overlay = document.querySelector(".overlay");
const modalBtn = document.querySelector(".btn-success");
const footer = document.querySelector("footer");
const modalTitle = document.querySelector(".modal-title");
const bonusTime = document.querySelector(".time-add");
const level = document.querySelector("#level");
const option = document.querySelectorAll(".levelOpt");

inputText.focus();

let word;
let timer = 10;
let userScore = 0;
let gameLevel = "Easy";
let bonus;

const randomWord = () => {
  const random = Math.floor(Math.random() * words.length);
  word = words[random];
  randomText.textContent = word;
};

randomWord();

level.addEventListener("change", () => {
  // level.forEach((el) => {
  gameLevel = level.value;
  // });
  console.log(gameLevel);
});

inputText.addEventListener("input", () => {
  if (inputText.value == word) {
    randomWord();
    userScore++;
    if (gameLevel == "Hard") {
      bonus = 2;
    } else if (gameLevel == "Medium") {
      bonus = 3;
    } else if (gameLevel == "Easy") {
      bonus = 5;
    }

    score.textContent = userScore;
    timer = timer + bonus;

    bonusTime.textContent = `+${bonus}`;
    bonusTime.style.opacity = 1;
    setTimeout(() => {
      bonusTime.style.opacity = 0;
    }, 1500);
    inputText.value = "";
  }
});

setInterval(() => {
  timer--;
  if (timer >= 0) {
    time.textContent = `00:${timer < 10 ? "0" + timer : timer}`;
    if (timer == 0) {
      modal.classList.remove("d-none");
      overlay.classList.remove("d-none");
      inputText.disabled = true;
      modalTitle.textContent = userScore;
    } else if (timer <= 2) {
      footer.classList.add("bg-danger");
    } else if (timer <= 5) {
      footer.classList.add("bg-warning");
    } else if (timer <= 10) {
      footer.classList.remove("bg-danger");
      footer.classList.remove("bg-warning");
    }
  }
}, 1000);

modalBtn.addEventListener("click", () => {
  modal.classList.add("d-none");
  overlay.classList.add("d-none");
  inputText.disabled = false;
  timer = 10;
  userScore = 0;
  score.textContent = userScore;
  footer.classList.remove("bg-danger");
  footer.classList.remove("bg-warning");
});
